//
//  NSBundle+Category.h
//  gongCheng
//
//  Created by user on 16/4/18.
//  Copyright © 2016年 user. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NSBundle (Category)

/// 获取试图
+ (id)loadNidViewWithName:(NSString *)name;

@end
