//
//  NSBundle+Category.m
//  gongCheng
//
//  Created by user on 16/4/18.
//  Copyright © 2016年 user. All rights reserved.
//

#import "NSBundle+Category.h"

@implementation NSBundle (Category)

/// 获取试图
+ (id)loadNidViewWithName:(NSString *)name{
    return [[NSBundle mainBundle] loadNibNamed:name owner:self options:nil].lastObject;
}

@end
