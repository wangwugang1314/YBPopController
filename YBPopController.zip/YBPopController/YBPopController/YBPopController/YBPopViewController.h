//
//  YBVC.h
//  zhuanChengAnimation
//
//  Created by FuYun on 16/10/19.
//  Copyright © 2016年 FuYun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YBPopViewController : UIViewController

+ (void)popViewWithView:(UIView *)popView clickHiden:(BOOL)clickHiden;

+ (void)hideVC;

@end
