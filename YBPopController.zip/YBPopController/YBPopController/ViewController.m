//
//  ViewController.m
//  YBPopController
//
//  Created by 王亚彬 on 2017/3/9.
//  Copyright © 2017年 王亚彬. All rights reserved.
//

#import "ViewController.h"
#import "YBPopViewController.h"
#import "NSBundle+Category.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    UIView *popView = [NSBundle loadNidViewWithName:@"YBPopView"];
    [YBPopViewController popViewWithView:popView clickHiden:YES];
//    [self.view addSubview:popView];
}


@end
